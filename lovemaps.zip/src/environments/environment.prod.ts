export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBN8mYwWWe5qs8VpJTw_LNFObtVuh-s-vE",
    authDomain: "demos-1081.firebaseapp.com",
    databaseURL: "https://demos-1081.firebaseio.com",
    projectId: "demos-1081",
    storageBucket: "",
    messagingSenderId: "955741029846"
  }
};
